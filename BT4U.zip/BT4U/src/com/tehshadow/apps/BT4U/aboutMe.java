package com.tehshadow.apps.BT4U;

import com.tehshadow.apps.BT4U.R;

import android.app.Activity;
import android.os.Bundle;

/*
 * This class is used to create the about me page activity
 */
public class aboutMe extends Activity {
	
	  @Override
	  public void onCreate(Bundle savedInstanceState) {
	    super.onCreate(savedInstanceState);
	    setContentView(R.layout.about);

	  
	  }
	

}
